# Duy Nguyen | Portfolio

Personal portfolio of Nguyen Khuong Duy, a student entrepreneur from Vietnam: founder of the Mr.Bas summer café, 3rd Prize at the Asian Business Simulation, and big brother of three.

The site is a single static page styled like a bubble tea shop. It has no build step and no dependencies: plain HTML, CSS and a few lines of JavaScript.

## Project structure

```
duy-portfolio/
├── index.html              Page content (all text lives here)
├── .nojekyll               Tells GitHub Pages to serve files as they are
├── README.md
└── assets/
    ├── css/styles.css      Colours, fonts, layout, light and dark mode
    ├── js/app.js           Mobile menu and photo viewer
    └── img/                Photos, favicon and social preview image
```

## Preview on your computer

Double-click `index.html` to open it in a browser.

For a preview that behaves exactly like the live site, run a local server from this folder:

```
python3 -m http.server 8000
```

Then open http://localhost:8000.

## Publish with GitHub Pages

1. Create a new **public** repository on GitHub, for example `duy-portfolio`.
2. Upload everything in this folder: `index.html`, `README.md`, `.nojekyll` and the whole `assets` folder.
3. Open **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, select the `main` branch and the `/ (root)` folder, then click **Save**.
4. After a minute or two the site is live at `https://USERNAME.github.io/duy-portfolio/`.

Tip: if the repository is named `USERNAME.github.io`, the site is published at `https://USERNAME.github.io/` instead.

After publishing, open `index.html` and change the `og:image` line to the full URL of `assets/img/og-cover.jpg`. This makes the preview card appear when the link is shared on Messenger, Zalo, email and social media.

## Editing

- **Text:** everything is in `index.html`, one commented block per section (`HERO`, `STORY`, `MR.BAS`, `ABS` and so on).
- **Photos:** put a new `.jpg` in `assets/img/` (about 900 px on the long side keeps the page fast), then point an `<img src="...">` to it and update its `alt` text and caption.
- **Colours:** change the variables at the top of `assets/css/styles.css`. Light mode is in the first `:root` block; dark mode is in the two blocks after it.
- **Keep out of search engines (optional):** add `<meta name="robots" content="noindex">` inside `<head>`. The site will still open for anyone who has the link.

## Credits

- Fonts: [Montserrat](https://fonts.google.com/specimen/Montserrat) and [Patrick Hand](https://fonts.google.com/specimen/Patrick+Hand), loaded from Google Fonts (SIL Open Font License).
- Photos and written content © 2026 Nguyen Khuong Duy. All rights reserved.
