(function () {
  // Mobile menu
  var btn = document.querySelector('.menu-btn');
  var links = document.getElementById('nav-links');
  function closeMenu() {
    links.classList.remove('open');
    btn.setAttribute('aria-expanded', 'false');
    btn.textContent = 'Menu';
  }
  if (btn && links) {
    btn.addEventListener('click', function () {
      var open = links.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      btn.textContent = open ? 'Close' : 'Menu';
    });
    links.addEventListener('click', function (e) {
      if (e.target.closest('a')) closeMenu();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && links.classList.contains('open')) closeMenu();
    });
  }

  // Photo lightbox
  var lb = document.getElementById('lightbox');
  if (lb && typeof lb.showModal === 'function') {
    var big = lb.querySelector('img');
    var cap = lb.querySelector('figcaption');
    document.querySelectorAll('.zoom').forEach(function (z) {
      z.addEventListener('click', function () {
        var small = z.querySelector('img');
        var fc = z.closest('figure').querySelector('figcaption');
        big.src = small.src;
        big.alt = small.alt;
        cap.textContent = fc ? fc.textContent : '';
        lb.showModal();
      });
    });
    lb.querySelector('.lb-close').addEventListener('click', function () { lb.close(); });
    lb.addEventListener('click', function (e) { if (e.target === lb) lb.close(); });
  } else {
    document.querySelectorAll('.zoom').forEach(function (z) { z.style.cursor = 'default'; });
  }
})();
